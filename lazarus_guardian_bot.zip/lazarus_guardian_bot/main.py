import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.storage.redis import RedisStorage
from aiogram.types import BotCommand

from app.config import settings
from app.database import init_db
from app.handlers import admin, common, moderation, activity, stats, games, coins, welcomes, applications


async def set_commands(bot: Bot) -> None:
    commands = [
        BotCommand(command="start", description="Запуск / информация"),
        BotCommand(command="help", description="Команды бота"),
        BotCommand(command="panel", description="Панель группы"),
        BotCommand(command="games", description="Игры"),
        BotCommand(command="lazarus", description="Lazarus игры"),
        BotCommand(command="top", description="Топ активности"),
        BotCommand(command="fk", description="Статистика группы/пользователя"),
        BotCommand(command="job", description="Добыть монеты"),
        BotCommand(command="upgrade", description="Улучшить прибор"),
    ]
    await bot.set_my_commands(commands)


async def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )
    await init_db()

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    storage = RedisStorage.from_url(settings.redis_url) if settings.redis_url else MemoryStorage()
    dp = Dispatcher(storage=storage)

    for router in (
        common.router,
        admin.router,
        moderation.router,
        stats.router,
        games.router,
        coins.router,
        welcomes.router,
        applications.router,
        activity.router,  # должен быть последним: ловит обычные сообщения
    ):
        dp.include_router(router)

    await set_commands(bot)
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    asyncio.run(main())
