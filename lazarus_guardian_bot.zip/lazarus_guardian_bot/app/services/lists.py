from __future__ import annotations

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import BlackListUser, StopWord, WhiteListUser
from app.utils.text import normalize_words


async def add_stop_words(session: AsyncSession, chat_id: int, words_text: str) -> int:
    words = normalize_words(words_text)
    added = 0
    for word in words:
        exists = await session.execute(select(StopWord.id).where(StopWord.chat_id == chat_id, StopWord.word == word).limit(1))
        if exists.scalar_one_or_none() is not None:
            continue
        session.add(StopWord(chat_id=chat_id, word=word))
        added += 1
    await session.flush()
    return added


async def remove_stop_words(session: AsyncSession, chat_id: int, words_text: str) -> int:
    words = normalize_words(words_text)
    if not words:
        return 0
    result = await session.execute(delete(StopWord).where(StopWord.chat_id == chat_id, StopWord.word.in_(words)))
    return int(result.rowcount or 0)


async def get_stop_words(session: AsyncSession, chat_id: int) -> list[str]:
    rows = await session.execute(select(StopWord.word).where(StopWord.chat_id == chat_id).order_by(StopWord.word))
    return list(rows.scalars().all())


async def add_list_user(session: AsyncSession, model: type[WhiteListUser] | type[BlackListUser], chat_id: int, user_key: str) -> bool:
    user_key = user_key.strip().lower()
    if not user_key:
        return False
    exists = await session.execute(select(model.id).where(model.chat_id == chat_id, model.user_key == user_key).limit(1))
    if exists.scalar_one_or_none() is not None:
        return False
    session.add(model(chat_id=chat_id, user_key=user_key))
    await session.flush()
    return True


async def del_list_user(session: AsyncSession, model: type[WhiteListUser] | type[BlackListUser], chat_id: int, user_key: str) -> int:
    user_key = user_key.strip().lower()
    result = await session.execute(delete(model).where(model.chat_id == chat_id, model.user_key == user_key))
    return int(result.rowcount or 0)


async def get_list_users(session: AsyncSession, model: type[WhiteListUser] | type[BlackListUser], chat_id: int) -> list[str]:
    rows = await session.execute(select(model.user_key).where(model.chat_id == chat_id).order_by(model.user_key))
    return list(rows.scalars().all())


async def is_in_list(session: AsyncSession, model: type[WhiteListUser] | type[BlackListUser], chat_id: int, keys: list[str]) -> bool:
    keys = [k.strip().lower() for k in keys if k]
    if not keys:
        return False
    row = await session.execute(select(model.id).where(model.chat_id == chat_id, model.user_key.in_(keys)).limit(1))
    return row.scalar_one_or_none() is not None
