from __future__ import annotations

import random

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Squad, SquadMember, UserProfile

UPGRADE_COSTS = {level: level * 250 for level in range(1, 15)}


async def ensure_profile(session: AsyncSession, user_id: int, username: str | None, full_name: str | None) -> UserProfile:
    profile = await session.get(UserProfile, user_id)
    if not profile:
        profile = UserProfile(user_id=user_id, username=username, full_name=full_name, last_username=username, last_full_name=full_name)
        session.add(profile)
        await session.flush()
    return profile


async def mine(session: AsyncSession, user_id: int, username: str | None, full_name: str | None) -> tuple[int, int, int]:
    profile = await ensure_profile(session, user_id, username, full_name)
    chance = min(95, 35 + profile.device_level * 4)
    if random.randint(1, 100) > chance:
        await session.flush()
        return 0, profile.coins, profile.device_level
    amount = random.randint(10, 50) * profile.device_level
    profile.coins += amount

    member_row = await session.execute(select(SquadMember).where(SquadMember.user_id == user_id))
    member = member_row.scalar_one_or_none()
    if member:
        squad = await session.get(Squad, member.squad_id)
        if squad:
            squad.storage_coins += amount // 10
    await session.flush()
    return amount, profile.coins, profile.device_level


async def upgrade_device(session: AsyncSession, user_id: int, username: str | None, full_name: str | None) -> tuple[bool, str]:
    profile = await ensure_profile(session, user_id, username, full_name)
    if profile.device_level >= 15:
        return False, "Прибор уже на максимальном уровне 15."
    cost = UPGRADE_COSTS.get(profile.device_level, profile.device_level * 250)
    if profile.coins < cost:
        return False, f"Не хватает монет. Нужно {cost}, на балансе {profile.coins}."
    profile.coins -= cost
    profile.device_level += 1
    await session.flush()
    return True, f"Прибор улучшен до уровня {profile.device_level}. Баланс: {profile.coins}."


async def rush(session: AsyncSession, user_id: int, amount: int, username: str | None, full_name: str | None) -> tuple[bool, str]:
    profile = await ensure_profile(session, user_id, username, full_name)
    if amount <= 0:
        return False, "Ставка должна быть больше 0."
    if profile.coins < amount:
        return False, "Не хватает монет."
    profile.coins -= amount
    if random.choice([True, False]):
        win = amount * 2
        profile.coins += win
        await session.flush()
        return True, f"Rush Coins: победа +{win}. Баланс: {profile.coins}."
    await session.flush()
    return False, f"Rush Coins: проигрыш -{amount}. Баланс: {profile.coins}."


async def create_squad(session: AsyncSession, owner_id: int, name: str) -> tuple[bool, str]:
    name = name.strip()[:128]
    if not name:
        return False, "Укажи название сквада."
    existing_member = await session.execute(select(SquadMember).where(SquadMember.user_id == owner_id))
    if existing_member.scalar_one_or_none():
        return False, "Ты уже состоишь в скваде."
    squad = Squad(name=name, owner_id=owner_id)
    session.add(squad)
    await session.flush()
    session.add(SquadMember(squad_id=squad.id, user_id=owner_id))
    await session.flush()
    return True, f"Сквад «{name}» создан."


async def invite_to_squad(session: AsyncSession, owner_id: int, target_id: int) -> tuple[bool, str]:
    owner_member_row = await session.execute(select(SquadMember).where(SquadMember.user_id == owner_id))
    owner_member = owner_member_row.scalar_one_or_none()
    if not owner_member:
        return False, "Сначала создай сквад: /sqcreate название"
    squad = await session.get(Squad, owner_member.squad_id)
    if not squad or squad.owner_id != owner_id:
        return False, "Приглашать может только владелец сквада."
    target_row = await session.execute(select(SquadMember).where(SquadMember.user_id == target_id))
    if target_row.scalar_one_or_none():
        return False, "Пользователь уже в скваде."
    session.add(SquadMember(squad_id=squad.id, user_id=target_id))
    await session.flush()
    return True, "Пользователь добавлен в сквад."


async def leave_squad(session: AsyncSession, user_id: int) -> tuple[bool, str]:
    result = await session.execute(delete(SquadMember).where(SquadMember.user_id == user_id))
    if int(result.rowcount or 0) == 0:
        return False, "Ты не состоишь в скваде."
    await session.flush()
    return True, "Ты покинул сквад."
