from __future__ import annotations

from aiogram.types import User
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import UserProfile


async def get_or_create_user(session: AsyncSession, tg_user: User) -> tuple[UserProfile, list[str]]:
    profile = await session.get(UserProfile, tg_user.id)
    changes: list[str] = []
    full_name = tg_user.full_name
    username = tg_user.username
    if not profile:
        profile = UserProfile(
            user_id=tg_user.id,
            username=username,
            full_name=full_name,
            last_username=username,
            last_full_name=full_name,
        )
        session.add(profile)
        await session.flush()
        return profile, changes

    if profile.last_full_name and profile.last_full_name != full_name:
        changes.append(f"Имя: <b>{profile.last_full_name}</b> → <b>{full_name}</b>")
    if (profile.last_username or username) and profile.last_username != username:
        old = f"@{profile.last_username}" if profile.last_username else "без username"
        new = f"@{username}" if username else "без username"
        changes.append(f"Username: <b>{old}</b> → <b>{new}</b>")

    profile.username = username
    profile.full_name = full_name
    profile.last_username = username
    profile.last_full_name = full_name
    await session.flush()
    return profile, changes
