from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings as app_settings
from app.models import ChatSettings


async def get_or_create_chat_settings(session: AsyncSession, chat_id: int, title: str | None = None) -> ChatSettings:
    row = await session.get(ChatSettings, chat_id)
    if row:
        if title and row.title != title:
            row.title = title
        return row
    row = ChatSettings(
        chat_id=chat_id,
        title=title,
        stop_warning_text=app_settings.default_warning_text,
        blacklist_text=app_settings.default_blacklist_text,
        forward_warning_text=app_settings.default_forward_warning,
    )
    session.add(row)
    await session.flush()
    return row


async def toggle_bool(session: AsyncSession, chat_id: int, field_name: str) -> ChatSettings:
    cfg = await get_or_create_chat_settings(session, chat_id)
    current = bool(getattr(cfg, field_name))
    setattr(cfg, field_name, not current)
    await session.flush()
    return cfg
