from __future__ import annotations

from datetime import datetime, timedelta, timezone

from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.types import ChatPermissions, Message, User
from sqlalchemy import delete, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import Debtor, WarningRecord


async def require_admin(message: Message) -> bool:
    if not message.from_user or message.chat.type == "private":
        await message.answer("Команда работает только в группе.")
        return False
    member = await message.bot.get_chat_member(message.chat.id, message.from_user.id)
    if member.status not in {"creator", "administrator"}:
        await message.answer("⛔ Команда доступна только администраторам.")
        return False
    return True


async def target_from_message(message: Message) -> tuple[int | None, str | None]:
    if message.reply_to_message and message.reply_to_message.from_user:
        u = message.reply_to_message.from_user
        return u.id, u.username
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        return None, None
    arg = parts[1].strip()
    if arg.startswith("@"):
        return None, arg.lstrip("@")
    if arg.lstrip("-").isdigit():
        return int(arg), None
    return None, arg


async def ban_user(bot: Bot, chat_id: int, user_id: int) -> bool:
    try:
        await bot.ban_chat_member(chat_id, user_id)
        return True
    except (TelegramBadRequest, TelegramForbiddenError):
        return False


async def unban_user(bot: Bot, chat_id: int, user_id: int) -> bool:
    try:
        await bot.unban_chat_member(chat_id, user_id, only_if_banned=True)
        return True
    except (TelegramBadRequest, TelegramForbiddenError):
        return False


async def mute_user(bot: Bot, chat_id: int, user_id: int, minutes: int = 60) -> bool:
    until = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    permissions = ChatPermissions(can_send_messages=False)
    try:
        await bot.restrict_chat_member(chat_id, user_id, permissions=permissions, until_date=until)
        return True
    except (TelegramBadRequest, TelegramForbiddenError):
        return False


async def unmute_user(bot: Bot, chat_id: int, user_id: int) -> bool:
    permissions = ChatPermissions(
        can_send_messages=True,
        can_send_audios=True,
        can_send_documents=True,
        can_send_photos=True,
        can_send_videos=True,
        can_send_video_notes=True,
        can_send_voice_notes=True,
        can_send_polls=True,
        can_send_other_messages=True,
        can_add_web_page_previews=True,
    )
    try:
        await bot.restrict_chat_member(chat_id, user_id, permissions=permissions)
        return True
    except (TelegramBadRequest, TelegramForbiddenError):
        return False


async def add_warning(session: AsyncSession, chat_id: int, user_id: int, reason: str | None = None) -> int:
    session.add(WarningRecord(chat_id=chat_id, user_id=user_id, reason=reason))
    await session.flush()
    rows = await session.execute(select(func.count(WarningRecord.id)).where(WarningRecord.chat_id == chat_id, WarningRecord.user_id == user_id))
    return int(rows.scalar() or 0)


async def clear_warning(session: AsyncSession, chat_id: int, user_id: int) -> int:
    row = await session.execute(
        select(WarningRecord.id).where(WarningRecord.chat_id == chat_id, WarningRecord.user_id == user_id).order_by(WarningRecord.id.desc()).limit(1)
    )
    warning_id = row.scalar_one_or_none()
    if warning_id is None:
        return 0
    result = await session.execute(delete(WarningRecord).where(WarningRecord.id == warning_id))
    return int(result.rowcount or 0)


async def apply_warning_type(bot: Bot, session: AsyncSession, chat_id: int, user: User, warning_type: str, reason: str) -> str:
    if warning_type == "ban":
        ok = await ban_user(bot, chat_id, user.id)
        return "бан" if ok else "бан не выдан: нет прав"
    if warning_type == "mute":
        ok = await mute_user(bot, chat_id, user.id, 60)
        return "мут на 60 минут" if ok else "мут не выдан: нет прав"
    if warning_type == "warn":
        count = await add_warning(session, chat_id, user.id, reason)
        return f"warn #{count}"
    return "без наказания"


async def add_debtor(session: AsyncSession, chat_id: int, user_id: int, username: str | None, reason: str | None) -> bool:
    exists = await session.execute(select(Debtor.id).where(Debtor.chat_id == chat_id, Debtor.user_id == user_id).limit(1))
    if exists.scalar_one_or_none() is not None:
        return False
    session.add(Debtor(chat_id=chat_id, user_id=user_id, username=username, reason=reason))
    await session.flush()
    return True


async def del_debtor(session: AsyncSession, chat_id: int, user_id: int) -> int:
    result = await session.execute(delete(Debtor).where(Debtor.chat_id == chat_id, Debtor.user_id == user_id))
    return int(result.rowcount or 0)
