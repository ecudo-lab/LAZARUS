from __future__ import annotations

import random
from datetime import datetime, timezone

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models import BingoLine, GameParticipant, GameSession
from app.utils.text import valid_bingo_numbers

GAME_LABELS = {
    "dice": "🎲 Кости",
    "darts": "🎯 Дартс",
    "basketball": "🏀 Баскетбол",
    "bowling": "🎳 Боулинг",
    "roulette_hashtag": "🎰 Рулетка по хэштегу",
    "roulette_list": "🎰 Рулетка по списку",
    "bingo": "🎰 Бинго",
}

ROLL_ACTIONS = {
    "dice": "🎲 Бросить кости",
    "darts": "🎯 Бросить дротик",
    "basketball": "🏀 Бросить мяч",
    "bowling": "🎳 Бросить шар",
}


async def active_session(session: AsyncSession, chat_id: int) -> GameSession | None:
    rows = await session.execute(
        select(GameSession)
        .options(selectinload(GameSession.participants))
        .where(GameSession.chat_id == chat_id, GameSession.status.in_(["registration", "running", "stopped"]))
        .order_by(GameSession.id.desc())
        .limit(1)
    )
    return rows.scalar_one_or_none()


async def create_session(session: AsyncSession, chat_id: int, game_type: str, hashtag: str | None = None) -> GameSession:
    old = await active_session(session, chat_id)
    if old and old.status != "finished":
        old.status = "finished"
        old.finished_at = datetime.now(timezone.utc)
    item = GameSession(chat_id=chat_id, game_type=game_type, hashtag=hashtag, status="registration")
    session.add(item)
    await session.flush()
    return item


async def add_participant(
    session: AsyncSession,
    game: GameSession,
    user_id: int,
    display_name: str,
    slot: int | None = None,
    numbers: list[int] | None = None,
    allow_second: bool = False,
) -> tuple[bool, str]:
    if game.status != "registration":
        return False, "Запись уже закрыта."
    if game.game_type == "bingo" and not valid_bingo_numbers(numbers):
        return False, "Для бинго нужно 5 уникальных чисел от 1 до 100. Пример: #ник 1 2 3 4 5"

    existing = [p for p in game.participants if p.user_id == user_id]
    if existing and not allow_second:
        return False, "Ты уже записан."
    if len(existing) >= 2:
        return False, "Максимум две записи."
    if slot is not None and any(p.slot == slot for p in game.participants):
        return False, f"Слот {slot} уже занят."

    p = GameParticipant(
        session_id=game.id,
        chat_id=game.chat_id,
        user_id=user_id,
        display_name=display_name[:255],
        slot=slot,
        numbers=" ".join(map(str, numbers)) if numbers else None,
    )
    session.add(p)
    await session.flush()
    game.participants.append(p)
    return True, "Записан."


async def stop_registration(session: AsyncSession, chat_id: int) -> GameSession | None:
    game = await active_session(session, chat_id)
    if not game:
        return None
    game.status = "stopped"
    game.stopped_at = datetime.now(timezone.utc)
    await session.flush()
    return game


async def start_game(session: AsyncSession, session_id: int) -> GameSession | None:
    game = await session.get(GameSession, session_id, options=[selectinload(GameSession.participants)])
    if not game:
        return None
    game.status = "running"
    await session.flush()
    return game


async def choose_random_winner(session: AsyncSession, chat_id: int) -> GameParticipant | None:
    game = await active_session(session, chat_id)
    if not game or not game.participants:
        return None
    winner = random.choice(game.participants)
    game.status = "finished"
    game.finished_at = datetime.now(timezone.utc)
    await session.flush()
    return winner


async def register_roll(session: AsyncSession, session_id: int, user_id: int) -> tuple[GameParticipant | None, int | None]:
    game = await session.get(GameSession, session_id, options=[selectinload(GameSession.participants)])
    if not game or game.status != "running":
        return None, None
    participant = next((p for p in game.participants if p.user_id == user_id), None)
    if not participant:
        return None, None
    score = random.randint(1, 6)
    if game.game_type in {"darts", "basketball"}:
        score = random.randint(0, 6)
    if game.game_type == "bowling":
        score = random.randint(0, 6)
    participant.score += score
    await session.flush()
    return participant, score


async def add_bingo_lines(session: AsyncSession, game: GameSession, count: int = 1) -> list[int]:
    count = max(1, min(count, 5))
    existing_rows = await session.execute(select(BingoLine.number).where(BingoLine.session_id == game.id))
    existing = set(existing_rows.scalars().all())
    pool = [n for n in range(1, 101) if n not in existing]
    numbers = random.sample(pool, min(count, len(pool)))
    for number in numbers:
        session.add(BingoLine(session_id=game.id, number=number))
    await session.flush()
    return numbers


async def bingo_numbers(session: AsyncSession, game: GameSession) -> set[int]:
    rows = await session.execute(select(BingoLine.number).where(BingoLine.session_id == game.id))
    return set(rows.scalars().all())


async def verify_bingo(session: AsyncSession, chat_id: int, user_id: int, numbers: list[int]) -> bool:
    game = await active_session(session, chat_id)
    if not game or game.game_type != "bingo":
        return False
    drawn = await bingo_numbers(session, game)
    return set(numbers).issubset(drawn)


def participants_text(game: GameSession) -> str:
    if not game.participants:
        return "Список пуст."
    lines = []
    ordered = sorted(game.participants, key=lambda p: (p.slot if p.slot is not None else 10**9, p.created_at))
    for idx, p in enumerate(ordered, 1):
        slot = f"#{p.slot} " if p.slot else f"{idx}. "
        nums = f" — {p.numbers}" if p.numbers else ""
        score = f" | очки: {p.score}" if p.score else ""
        lines.append(f"{slot}{p.display_name}{nums}{score}")
    return "\n".join(lines)
