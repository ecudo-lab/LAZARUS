from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import MessageStat, PartnerTransition


async def record_message(session: AsyncSession, chat_id: int, user_id: int) -> None:
    session.add(MessageStat(chat_id=chat_id, user_id=user_id))
    await session.flush()


async def count_messages(session: AsyncSession, chat_id: int, user_id: int | None = None, since: datetime | None = None) -> int:
    query = select(func.count(MessageStat.id)).where(MessageStat.chat_id == chat_id)
    if user_id is not None:
        query = query.where(MessageStat.user_id == user_id)
    if since is not None:
        query = query.where(MessageStat.created_at >= since)
    result = await session.execute(query)
    return int(result.scalar() or 0)


async def user_activity_report(session: AsyncSession, chat_id: int, user_id: int) -> dict[str, int]:
    now = datetime.now(timezone.utc)
    return {
        "1 час": await count_messages(session, chat_id, user_id, now - timedelta(hours=1)),
        "24 часа": await count_messages(session, chat_id, user_id, now - timedelta(days=1)),
        "7 дней": await count_messages(session, chat_id, user_id, now - timedelta(days=7)),
        "Всего": await count_messages(session, chat_id, user_id, None),
    }


async def group_activity_report(session: AsyncSession, chat_id: int) -> dict[str, int]:
    now = datetime.now(timezone.utc)
    return {
        "1 час": await count_messages(session, chat_id, None, now - timedelta(hours=1)),
        "24 часа": await count_messages(session, chat_id, None, now - timedelta(days=1)),
        "7 дней": await count_messages(session, chat_id, None, now - timedelta(days=7)),
        "Всего": await count_messages(session, chat_id, None, None),
    }


async def top_users(session: AsyncSession, chat_id: int, since: datetime | None = None, limit: int = 10) -> list[tuple[int, int]]:
    query = select(MessageStat.user_id, func.count(MessageStat.id).label("cnt")).where(MessageStat.chat_id == chat_id)
    if since:
        query = query.where(MessageStat.created_at >= since)
    query = query.group_by(MessageStat.user_id).order_by(func.count(MessageStat.id).desc()).limit(limit)
    rows = await session.execute(query)
    return [(int(user_id), int(cnt)) for user_id, cnt in rows.all()]


async def record_partner_transition(session: AsyncSession, chat_id: int, user_id: int) -> None:
    session.add(PartnerTransition(chat_id=chat_id, user_id=user_id))
    await session.flush()
