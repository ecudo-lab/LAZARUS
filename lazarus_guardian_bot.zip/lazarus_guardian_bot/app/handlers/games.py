from __future__ import annotations

import re

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message

from app.database import session_scope
from app.keyboards import games_kb, roll_kb, start_game_kb
from app.services.games import GAME_LABELS, ROLL_ACTIONS, active_session, add_bingo_lines, create_session, participants_text, register_roll, start_game, stop_registration, choose_random_winner
from app.services.moderation import require_admin

router = Router(name="games")


@router.message(Command("games"))
async def games_cmd(message: Message) -> None:
    await message.answer("🎮 <b>Игровые функции</b>\nВыбери игру:", reply_markup=games_kb())


@router.callback_query(F.data.startswith("game:new:"))
async def game_new(call: CallbackQuery) -> None:
    game_type = call.data.split(":", 2)[2]
    async with session_scope() as session:
        game = await create_session(session, call.message.chat.id, game_type)
    label = GAME_LABELS.get(game_type, game_type)
    extra = "\nДля бинго формат: <code>#ник 1 2 3 4 5</code>" if game_type == "bingo" else ""
    if game_type == "roulette_hashtag":
        extra = "\nЗадай точный хэштег сообщением в чат, например: <code>#игра</code>. Пока принимается любой #хэштег."
    await call.message.answer(
        f"{label}\n\nЗапись открыта.\n"
        f"Участники пишут <code>#текст</code> или <code>@текст</code>. Можно указать слот: <code>#текст 12</code>.{extra}\n\n"
        "Закрыть запись: /stop"
    )
    await call.answer("Игра создана")


@router.message(Command("stop"))
async def stop_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    async with session_scope() as session:
        game = await stop_registration(session, message.chat.id)
        if not game:
            await message.answer("Активной игры нет.")
            return
        text = participants_text(game)
        message_id = None
    sent = await message.answer(f"⛔ Запись закрыта.\n\n<b>Участники:</b>\n{text}", reply_markup=start_game_kb(game.id))
    async with session_scope() as session:
        game = await session.get(type(game), game.id)
        if game:
            game.pinned_message_id = sent.message_id
    try:
        await sent.pin(disable_notification=True)
    except Exception:
        pass


@router.callback_query(F.data.startswith("game:start:"))
async def game_start(call: CallbackQuery) -> None:
    session_id = int(call.data.rsplit(":", 1)[1])
    async with session_scope() as session:
        game = await start_game(session, session_id)
        if not game:
            await call.answer("Игра не найдена", show_alert=True)
            return
        text = participants_text(game)
    if game.game_type in {"roulette_list", "roulette_hashtag", "bingo"}:
        await call.message.answer("▶️ Игра запущена. Для рулетки: /random. Для бинго: /line или лайн 3.")
    else:
        action = ROLL_ACTIONS.get(game.game_type, "Бросить")
        await call.message.answer(f"▶️ Игра запущена.\n\n{text}", reply_markup=roll_kb(game.id, action))
    await call.answer("Старт")


@router.callback_query(F.data.startswith("game:roll:"))
async def game_roll(call: CallbackQuery) -> None:
    session_id = int(call.data.rsplit(":", 1)[1])
    async with session_scope() as session:
        participant, score = await register_roll(session, session_id, call.from_user.id)
    if not participant:
        await call.answer("Ты не участник или игра не активна.", show_alert=True)
        return
    await call.message.answer(f"🎲 {participant.display_name}: +{score} очков. Всего: {participant.score}")
    await call.answer()


@router.message(Command("random"))
async def random_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    async with session_scope() as session:
        winner = await choose_random_winner(session, message.chat.id)
    if not winner:
        await message.answer("Нет участников для выбора победителя.")
        return
    await message.answer(f"🎉 Победитель: <b>{winner.display_name}</b>")


@router.message(Command("line"))
@router.message(F.text.regexp(r"(?i)^лайн(?:\s+\d+)?$"))
async def line_cmd(message: Message) -> None:
    count = 1
    match = re.search(r"\d+", message.text or "")
    if match:
        count = int(match.group())
    async with session_scope() as session:
        game = await active_session(session, message.chat.id)
        if not game or game.game_type != "bingo":
            await message.answer("Активного бинго нет.")
            return
        numbers = await add_bingo_lines(session, game, count)
    await message.answer("🎰 Лайн: " + " ".join(map(str, numbers)))


@router.message(F.text.regexp(r"(?i)бинго"))
async def bingo_check(message: Message) -> None:
    nums = [int(x) for x in re.findall(r"\d+", message.text or "")]
    if len(nums) < 5:
        await message.answer("Для проверки укажи 5 чисел: <code>1 2 3 4 5 бинго</code>")
        return
    from app.services.games import verify_bingo
    async with session_scope() as session:
        ok = await verify_bingo(session, message.chat.id, message.from_user.id, nums[:5])
    if ok:
        sent = await message.answer(f"🎉 БИНГО подтверждено: {' '.join(map(str, nums[:5]))}")
        try:
            await sent.pin(disable_notification=True)
        except Exception:
            pass
    else:
        await message.answer("❌ Бинго не подтверждено.")
