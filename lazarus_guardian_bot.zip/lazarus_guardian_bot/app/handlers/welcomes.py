from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from sqlalchemy import delete, select

from app.database import session_scope
from app.models import WelcomeMessage
from app.services.moderation import require_admin

router = Router(name="welcomes")


@router.message(Command("setwelcome"))
async def set_welcome_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Используй: /setwelcome текст приветствия")
        return
    async with session_scope() as session:
        item = WelcomeMessage(chat_id=message.chat.id, text=parts[1])
        session.add(item)
        await session.flush()
        rows = await session.execute(select(WelcomeMessage.id).where(WelcomeMessage.chat_id == message.chat.id).order_by(WelcomeMessage.created_at.desc()))
        keep = set(rows.scalars().all()[:3])
        if keep:
            await session.execute(delete(WelcomeMessage).where(WelcomeMessage.chat_id == message.chat.id, WelcomeMessage.id.not_in(keep)))
    await message.answer("✅ Приветствие сохранено. Бот хранит последние 3 приветствия.")


@router.message(Command("welcome"))
async def welcome_list_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    async with session_scope() as session:
        rows = await session.execute(select(WelcomeMessage).where(WelcomeMessage.chat_id == message.chat.id).order_by(WelcomeMessage.created_at.desc()).limit(3))
        welcomes = rows.scalars().all()
    if not welcomes:
        await message.answer("Приветствия не настроены. Добавь: /setwelcome текст")
        return
    text = "\n\n".join(f"{i}. {w.text}" for i, w in enumerate(welcomes, 1))
    await message.answer("👋 <b>Приветствия группы</b>\n" + text)
