from datetime import datetime, timedelta, timezone

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import Message

from app.database import session_scope
from app.services.stats import group_activity_report, top_users, user_activity_report

router = Router(name="stats")


async def render_top(message: Message) -> None:
    now = datetime.now(timezone.utc)
    periods = [
        ("Актив за 1 час", now - timedelta(hours=1)),
        ("Актив за 24 часа", now - timedelta(days=1)),
        ("Актив за 7 дней", now - timedelta(days=7)),
        ("Актив всего", None),
    ]
    blocks = []
    async with session_scope() as session:
        for title, since in periods:
            rows = await top_users(session, message.chat.id, since)
            if not rows:
                body = "Пусто"
            else:
                lines = []
                for i, (user_id, count) in enumerate(rows, 1):
                    lines.append(f"{i}. <code>{user_id}</code> — {count}")
                body = "\n".join(lines)
            blocks.append(f"<blockquote expandable><b>{title}</b>\n{body}</blockquote>")
    await message.answer("🏆 <b>Топ по чату</b>\n" + "\n".join(blocks))


@router.message(Command("top"))
async def top_cmd(message: Message) -> None:
    await render_top(message)


@router.message(F.text.lower() == "топ")
async def top_text(message: Message) -> None:
    await render_top(message)


async def render_fk(message: Message) -> None:
    target = message.reply_to_message.from_user if message.reply_to_message and message.reply_to_message.from_user else message.from_user
    async with session_scope() as session:
        if target:
            report = await user_activity_report(session, message.chat.id, target.id)
            title = f"📈 ФК пользователя <b>{target.full_name}</b>"
        else:
            report = await group_activity_report(session, message.chat.id)
            title = "📈 ФК группы"
    lines = [f"{k}: <b>{v}</b>" for k, v in report.items()]
    await message.answer(title + "\n" + "\n".join(lines))


@router.message(Command("fk"))
async def fk_cmd(message: Message) -> None:
    await render_fk(message)


@router.message(F.text.lower() == "фк")
async def fk_text(message: Message) -> None:
    await render_fk(message)
