from __future__ import annotations

from datetime import datetime, timezone

from aiogram import F, Router
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import Command
from aiogram.types import ChatMemberUpdated, Message
from sqlalchemy import delete, select

from app.database import session_scope
from app.models import BlackListUser, ForwardLog, Trigger, WelcomeMessage, WhiteListUser
from app.services.games import active_session, add_participant
from app.services.lists import get_stop_words, is_in_list
from app.services.moderation import apply_warning_type, require_admin
from app.services.settings import get_or_create_chat_settings
from app.services.stats import record_message
from app.services.users import get_or_create_user
from app.utils.text import LONG_WORD_RE, parse_signup, user_key, valid_bingo_numbers

router = Router(name="activity")


@router.chat_member()
async def new_member_guard(event: ChatMemberUpdated) -> None:
    new = event.new_chat_member
    old = event.old_chat_member
    if new.status not in {"member", "restricted"} or old.status in {"member", "restricted", "administrator", "creator"}:
        return
    user = new.user
    async with session_scope() as session:
        cfg = await get_or_create_chat_settings(session, event.chat.id, event.chat.title)
        keys = [user_key(user.id, user.username), str(user.id)]
        in_black = await is_in_list(session, BlackListUser, event.chat.id, keys)
        rows = await session.execute(select(WelcomeMessage).where(WelcomeMessage.chat_id == event.chat.id).order_by(WelcomeMessage.created_at.desc()).limit(1))
        welcome = rows.scalar_one_or_none()
    if in_black:
        try:
            await event.bot.ban_chat_member(event.chat.id, user.id)
            await event.bot.send_message(event.chat.id, cfg.blacklist_text)
        except Exception:
            pass
        return
    if welcome:
        await event.bot.send_message(event.chat.id, welcome.text.replace("{name}", user.full_name))


@router.message(Command("triggers"))
async def triggers_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    async with session_scope() as session:
        rows = await session.execute(select(Trigger.name).where(Trigger.chat_id == message.chat.id).order_by(Trigger.name))
        names = rows.scalars().all()
    await message.answer("📌 <b>Триггеры</b>\n" + ("\n".join(names) if names else "Пусто"))


@router.message(Command("add"))
async def add_trigger_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    if not message.reply_to_message or not message.reply_to_message.text:
        await message.answer("Ответь на текстовое сообщение: /add название")
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Укажи название: /add название")
        return
    name = parts[1].strip().lower()[:128]
    async with session_scope() as session:
        old = await session.execute(select(Trigger).where(Trigger.chat_id == message.chat.id, Trigger.name == name))
        item = old.scalar_one_or_none()
        if item:
            item.text = message.reply_to_message.text
        else:
            session.add(Trigger(chat_id=message.chat.id, name=name, text=message.reply_to_message.text))
    await message.answer(f"✅ Триггер сохранён: <b>{name}</b>")


@router.message(Command("del"))
async def del_trigger_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Укажи название: /del название")
        return
    name = parts[1].strip().lower()
    async with session_scope() as session:
        result = await session.execute(delete(Trigger).where(Trigger.chat_id == message.chat.id, Trigger.name == name))
    await message.answer(f"✅ Удалено: {int(result.rowcount or 0)}")


async def handle_forward(message: Message, cfg) -> bool:
    if not (message.forward_origin or message.forward_date):
        return False
    user = message.from_user
    if not user:
        return False
    keys = [user_key(user.id, user.username), str(user.id)]
    async with session_scope() as session:
        allowed = await is_in_list(session, WhiteListUser, message.chat.id, keys)
        if allowed:
            return False
        row = await session.execute(select(ForwardLog).where(ForwardLog.chat_id == message.chat.id, ForwardLog.user_id == user.id))
        log = row.scalar_one_or_none()
        now = datetime.now(timezone.utc)
        if log:
            delta = now - log.last_forward_at
            if delta.total_seconds() < cfg.advert_interval_minutes * 60:
                try:
                    await message.delete()
                except Exception:
                    pass
                return True
            log.last_forward_at = now
        else:
            session.add(ForwardLog(chat_id=message.chat.id, user_id=user.id, last_forward_at=now))
    await message.answer(cfg.forward_warning_text)
    return False


@router.message(F.chat.type.in_({"group", "supergroup"}))
async def group_activity(message: Message) -> None:
    if not message.from_user or message.from_user.is_bot:
        return
    text = message.text or message.caption or ""
    async with session_scope() as session:
        cfg = await get_or_create_chat_settings(session, message.chat.id, message.chat.title)
        profile, changes = await get_or_create_user(session, message.from_user)
        await record_message(session, message.chat.id, message.from_user.id)
        stop_words = await get_stop_words(session, message.chat.id) if cfg.guardian_enabled else []
        keys = [user_key(message.from_user.id, message.from_user.username), str(message.from_user.id)]
        in_black = await is_in_list(session, BlackListUser, message.chat.id, keys)
        trigger_row = await session.execute(select(Trigger).where(Trigger.chat_id == message.chat.id, Trigger.name == text.strip().lower()).limit(1))
        trigger = trigger_row.scalar_one_or_none()

    if in_black:
        try:
            await message.bot.ban_chat_member(message.chat.id, message.from_user.id)
            await message.answer(cfg.blacklist_text)
        except Exception:
            pass
        return

    if cfg.name_checker_enabled or cfg.username_checker_enabled:
        filtered = []
        for item in changes:
            if item.startswith("Имя") and cfg.name_checker_enabled:
                filtered.append(item)
            if item.startswith("Username") and cfg.username_checker_enabled:
                filtered.append(item)
        if filtered:
            await message.answer("🔎 Обнаружена смена данных пользователя:\n" + "\n".join(filtered))

    if cfg.guardian_enabled and cfg.anti_long_words_enabled and LONG_WORD_RE.search(text):
        try:
            await message.delete()
        except Exception:
            pass
        await message.answer("🛡 Анти-длинные слова: сообщение удалено.")
        return

    if cfg.guardian_enabled and stop_words:
        low = text.lower()
        found = next((w for w in stop_words if w in low), None)
        if found:
            try:
                await message.delete()
            except Exception:
                pass
            async with session_scope() as session:
                action = await apply_warning_type(message.bot, session, message.chat.id, message.from_user, cfg.stop_warning_type, f"stop-word: {found}")
            await message.answer(f"{cfg.stop_warning_text}\nДействие: <b>{action}</b>")
            return

    if await handle_forward(message, cfg):
        return

    signup = parse_signup(text)
    if signup:
        _, slot, numbers = signup
        async with session_scope() as session:
            game = await active_session(session, message.chat.id)
            if game and game.status == "registration":
                ok, info = await add_participant(session, game, message.from_user.id, message.from_user.full_name, slot, numbers)
                await message.reply(("✅ " if ok else "❌ ") + info)
                return

    if trigger:
        await message.answer(trigger.text)
