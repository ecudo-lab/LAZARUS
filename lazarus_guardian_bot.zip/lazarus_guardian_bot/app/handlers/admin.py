from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select

from app.database import session_scope
from app.keyboards import admin_panel_kb, guardian_kb, list_menu_kb, warning_type_kb
from app.models import BlackListUser, ChatSettings, WhiteListUser
from app.services.lists import add_list_user, add_stop_words, del_list_user, get_list_users, get_stop_words, remove_stop_words
from app.services.moderation import require_admin
from app.services.settings import get_or_create_chat_settings, toggle_bool

router = Router(name="admin")


class AdminInput(StatesGroup):
    add_stop_words = State()
    del_stop_words = State()
    stop_warning_text = State()
    wl_add = State()
    wl_del = State()
    wl_text = State()
    bl_add = State()
    bl_del = State()
    bl_text = State()
    advert_interval = State()


@router.message(Command("panel"))
async def panel_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    async with session_scope() as session:
        await get_or_create_chat_settings(session, message.chat.id, message.chat.title)
    await message.answer("⚙️ <b>Панель управления группой</b>", reply_markup=admin_panel_kb())


@router.callback_query(F.data == "panel:back")
async def panel_back(call: CallbackQuery) -> None:
    await call.message.edit_text("⚙️ <b>Панель управления группой</b>", reply_markup=admin_panel_kb())
    await call.answer()


@router.callback_query(F.data == "panel:guardian")
async def guardian_panel(call: CallbackQuery) -> None:
    async with session_scope() as session:
        cfg = await get_or_create_chat_settings(session, call.message.chat.id, call.message.chat.title)
        await call.message.edit_text(
            "🛡 <b>Guardian</b>\nВключение защиты и чекеров.",
            reply_markup=guardian_kb(cfg.guardian_enabled, cfg.name_checker_enabled, cfg.username_checker_enabled, cfg.anti_long_words_enabled),
        )
    await call.answer()


@router.callback_query(F.data.startswith("toggle:"))
async def toggle_setting(call: CallbackQuery) -> None:
    field = call.data.split(":", 1)[1]
    allowed = {"guardian_enabled", "name_checker_enabled", "username_checker_enabled", "anti_long_words_enabled"}
    if field not in allowed:
        await call.answer("Неизвестный параметр", show_alert=True)
        return
    async with session_scope() as session:
        cfg = await toggle_bool(session, call.message.chat.id, field)
        await call.message.edit_reply_markup(reply_markup=guardian_kb(cfg.guardian_enabled, cfg.name_checker_enabled, cfg.username_checker_enabled, cfg.anti_long_words_enabled))
    await call.answer("Готово")


@router.callback_query(F.data == "stop:add")
async def stop_add(call: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminInput.add_stop_words)
    await call.message.answer("Введи стоп-слова. Каждое слово можно с новой строки.")
    await call.answer()


@router.message(AdminInput.add_stop_words)
async def stop_add_save(message: Message, state: FSMContext) -> None:
    async with session_scope() as session:
        added = await add_stop_words(session, message.chat.id, message.text or "")
    await state.clear()
    await message.answer(f"✅ Добавлено стоп-слов: {added}")


@router.callback_query(F.data == "stop:del")
async def stop_del(call: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminInput.del_stop_words)
    await call.message.answer("Введи стоп-слова, которые нужно удалить.")
    await call.answer()


@router.message(AdminInput.del_stop_words)
async def stop_del_save(message: Message, state: FSMContext) -> None:
    async with session_scope() as session:
        removed = await remove_stop_words(session, message.chat.id, message.text or "")
    await state.clear()
    await message.answer(f"✅ Удалено стоп-слов: {removed}")


@router.callback_query(F.data == "stop:type")
async def stop_type(call: CallbackQuery) -> None:
    await call.message.edit_text("⚠️ Выбери тип предупреждения за стоп-слово:", reply_markup=warning_type_kb())
    await call.answer()


@router.callback_query(F.data.startswith("stop_type:"))
async def stop_type_save(call: CallbackQuery) -> None:
    value = call.data.split(":", 1)[1]
    async with session_scope() as session:
        cfg = await get_or_create_chat_settings(session, call.message.chat.id, call.message.chat.title)
        cfg.stop_warning_type = value
    await call.message.edit_text(f"✅ Тип предупреждения установлен: <b>{value}</b>", reply_markup=admin_panel_kb())
    await call.answer()


@router.callback_query(F.data == "stop:text")
async def stop_text(call: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminInput.stop_warning_text)
    await call.message.answer("Введи текст предупреждения при срабатывании стоп-слов.")
    await call.answer()


@router.message(AdminInput.stop_warning_text)
async def stop_text_save(message: Message, state: FSMContext) -> None:
    async with session_scope() as session:
        cfg = await get_or_create_chat_settings(session, message.chat.id, message.chat.title)
        cfg.stop_warning_text = message.text or "⚠️ Нарушение."
    await state.clear()
    await message.answer("✅ Текст предупреждения сохранён.")


@router.callback_query(F.data == "wl:menu")
async def wl_menu(call: CallbackQuery) -> None:
    await call.message.edit_text("✅ <b>Белый список</b>", reply_markup=list_menu_kb("wl"))
    await call.answer()


@router.callback_query(F.data == "bl:menu")
async def bl_menu(call: CallbackQuery) -> None:
    await call.message.edit_text("⛔ <b>Чёрный список</b>", reply_markup=list_menu_kb("bl"))
    await call.answer()


@router.callback_query(F.data.in_({"wl:add", "wl:del", "wl:text", "bl:add", "bl:del", "bl:text"}))
async def list_actions(call: CallbackQuery, state: FSMContext) -> None:
    mapping = {
        "wl:add": (AdminInput.wl_add, "Введи ID или @username для добавления в БС."),
        "wl:del": (AdminInput.wl_del, "Введи ID или @username для удаления из БС."),
        "wl:text": (AdminInput.wl_text, "Введи текст предупреждения для пересылок."),
        "bl:add": (AdminInput.bl_add, "Введи ID или @username для добавления в ЧС."),
        "bl:del": (AdminInput.bl_del, "Введи ID или @username для удаления из ЧС."),
        "bl:text": (AdminInput.bl_text, "Введи текст предупреждения для ЧС."),
    }
    next_state, text = mapping[call.data]
    await state.set_state(next_state)
    await call.message.answer(text)
    await call.answer()


@router.callback_query(F.data.in_({"wl:list", "bl:list"}))
async def list_show(call: CallbackQuery) -> None:
    model = WhiteListUser if call.data.startswith("wl") else BlackListUser
    title = "Белый список" if call.data.startswith("wl") else "Чёрный список"
    async with session_scope() as session:
        users = await get_list_users(session, model, call.message.chat.id)
    text = "\n".join(users) if users else "Список пуст."
    await call.message.answer(f"<b>{title}</b>\n{text}")
    await call.answer()


@router.message(AdminInput.wl_add)
async def wl_add_save(message: Message, state: FSMContext) -> None:
    async with session_scope() as session:
        ok = await add_list_user(session, WhiteListUser, message.chat.id, (message.text or "").strip().lower())
    await state.clear()
    await message.answer("✅ Добавлено в БС." if ok else "Уже есть или неверный ввод.")


@router.message(AdminInput.wl_del)
async def wl_del_save(message: Message, state: FSMContext) -> None:
    async with session_scope() as session:
        removed = await del_list_user(session, WhiteListUser, message.chat.id, (message.text or "").strip().lower())
    await state.clear()
    await message.answer(f"✅ Удалено из БС: {removed}")


@router.message(AdminInput.bl_add)
async def bl_add_save(message: Message, state: FSMContext) -> None:
    async with session_scope() as session:
        ok = await add_list_user(session, BlackListUser, message.chat.id, (message.text or "").strip().lower())
    await state.clear()
    await message.answer("✅ Добавлено в ЧС." if ok else "Уже есть или неверный ввод.")


@router.message(AdminInput.bl_del)
async def bl_del_save(message: Message, state: FSMContext) -> None:
    async with session_scope() as session:
        removed = await del_list_user(session, BlackListUser, message.chat.id, (message.text or "").strip().lower())
    await state.clear()
    await message.answer(f"✅ Удалено из ЧС: {removed}")


@router.message(AdminInput.wl_text)
async def wl_text_save(message: Message, state: FSMContext) -> None:
    async with session_scope() as session:
        cfg = await get_or_create_chat_settings(session, message.chat.id, message.chat.title)
        cfg.forward_warning_text = message.text or "⚠️ Пересылка запрещена."
    await state.clear()
    await message.answer("✅ Текст БС/пересылок сохранён.")


@router.message(AdminInput.bl_text)
async def bl_text_save(message: Message, state: FSMContext) -> None:
    async with session_scope() as session:
        cfg = await get_or_create_chat_settings(session, message.chat.id, message.chat.title)
        cfg.blacklist_text = message.text or "⛔ Пользователь в ЧС."
    await state.clear()
    await message.answer("✅ Текст ЧС сохранён.")
