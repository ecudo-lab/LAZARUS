from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.database import session_scope
from app.models import BlackListUser, WhiteListUser
from app.services.lists import add_list_user, del_list_user
from app.services.moderation import add_debtor, add_warning, ban_user, clear_warning, del_debtor, mute_user, require_admin, target_from_message, unban_user, unmute_user

router = Router(name="moderation")


@router.message(Command("ban"))
async def ban_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    user_id, _ = await target_from_message(message)
    if not user_id:
        await message.answer("Ответь на сообщение пользователя или укажи ID.")
        return
    ok = await ban_user(message.bot, message.chat.id, user_id)
    await message.answer("✅ Пользователь забанен." if ok else "❌ Не удалось забанить. Проверь права бота.")


@router.message(Command("unban"))
async def unban_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    user_id, _ = await target_from_message(message)
    if not user_id:
        await message.answer("Укажи ID пользователя.")
        return
    ok = await unban_user(message.bot, message.chat.id, user_id)
    await message.answer("✅ Бан снят." if ok else "❌ Не удалось снять бан.")


@router.message(Command("mute"))
async def mute_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    user_id, _ = await target_from_message(message)
    if not user_id:
        await message.answer("Ответь на сообщение пользователя или укажи ID.")
        return
    ok = await mute_user(message.bot, message.chat.id, user_id, 60)
    await message.answer("✅ Мут на 60 минут." if ok else "❌ Не удалось выдать мут.")


@router.message(Command("unmute"))
async def unmute_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    user_id, _ = await target_from_message(message)
    if not user_id:
        await message.answer("Ответь на сообщение пользователя или укажи ID.")
        return
    ok = await unmute_user(message.bot, message.chat.id, user_id)
    await message.answer("✅ Мут снят." if ok else "❌ Не удалось снять мут.")


@router.message(Command("warn"))
async def warn_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    user_id, _ = await target_from_message(message)
    if not user_id:
        await message.answer("Ответь на сообщение пользователя или укажи ID.")
        return
    async with session_scope() as session:
        count = await add_warning(session, message.chat.id, user_id, "manual warn")
    await message.answer(f"⚠️ Предупреждение выдано. Всего: {count}")


@router.message(Command("unwarn"))
async def unwarn_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    user_id, _ = await target_from_message(message)
    if not user_id:
        await message.answer("Ответь на сообщение пользователя или укажи ID.")
        return
    async with session_scope() as session:
        removed = await clear_warning(session, message.chat.id, user_id)
    await message.answer(f"✅ Снято предупреждений: {removed}")


@router.message(Command("free"))
async def free_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    user_id, username = await target_from_message(message)
    key = f"@{username.lower()}" if username else str(user_id or "")
    async with session_scope() as session:
        ok = await add_list_user(session, WhiteListUser, message.chat.id, key)
    await message.answer("✅ Добавлено в БС." if ok else "Не добавлено.")


@router.message(Command("unfree"))
async def unfree_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    user_id, username = await target_from_message(message)
    key = f"@{username.lower()}" if username else str(user_id or "")
    async with session_scope() as session:
        removed = await del_list_user(session, WhiteListUser, message.chat.id, key)
    await message.answer(f"✅ Удалено из БС: {removed}")


@router.message(Command("adolg"))
async def add_debtor_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    if not message.reply_to_message or not message.reply_to_message.from_user:
        await message.answer("Команда работает ответом на сообщение должника: /adolg причина")
        return
    reason = (message.text or "").split(maxsplit=1)[1] if len((message.text or "").split(maxsplit=1)) > 1 else None
    u = message.reply_to_message.from_user
    async with session_scope() as session:
        ok = await add_debtor(session, message.chat.id, u.id, u.username, reason)
    await message.answer("✅ Должник добавлен." if ok else "Не удалось добавить / уже есть.")


@router.message(Command("deldolg"))
async def del_debtor_cmd(message: Message) -> None:
    if not await require_admin(message):
        return
    if not message.reply_to_message or not message.reply_to_message.from_user:
        await message.answer("Команда работает ответом на сообщение: /deldolg")
        return
    async with session_scope() as session:
        removed = await del_debtor(session, message.chat.id, message.reply_to_message.from_user.id)
    await message.answer(f"✅ Удалено из должников: {removed}")
