from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

router = Router(name="common")

HELP_TEXT = """
<b>Lazarus Guardian Bot</b>

<b>Панель:</b>
/panel — настройки группы
/games — меню игр
/lazarus — Кроко / Кроко AI / Мафия

<b>Статистика:</b>
Топ или /top — топ активности
Фк или /fk — статистика группы/пользователя

<b>Монеты:</b>
/job, /task, добыть, работать — добыча монет
/upgrade — улучшить прибор
/rush 100 — игра на монеты
/sqcreate Название — создать сквад
/inv — ответом пригласить в сквад
/sqleave — покинуть сквад

<b>Триггеры:</b>
/triggers — список
/add название — ответом сохранить сообщение
/del название — удалить

<b>Модерация:</b>
/ban /unban /mute /unmute /warn /unwarn — ответом или по ID
/free /unfree — белый список вручную
/adolg /deldolg — должники по играм
""".strip()


@router.message(CommandStart())
async def start_cmd(message: Message) -> None:
    if message.chat.type == "private":
        await message.answer(
            "🐊 <b>Lazarus Guardian</b>\n\n"
            "Добавь меня в группу и выдай права администратора.\n"
            "После этого в группе используй /panel."
        )
    else:
        await message.answer("✅ Бот работает. Панель: /panel. Помощь: /help")


@router.message(Command("help"))
async def help_cmd(message: Message) -> None:
    await message.answer(HELP_TEXT)


@router.message(Command("lazarus"))
async def lazarus_cmd(message: Message) -> None:
    await message.answer(
        "🐊 <b>Игры Lazarus</b>\n\n"
        "Кроко, Кроко AI и Мафия заложены в структуру проекта как отдельные модули.\n"
        "Сейчас включён каркас меню, чтобы можно было дописать механику под твои правила."
    )
