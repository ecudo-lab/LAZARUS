from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import Message

from app.database import session_scope
from app.services.coins import create_squad, invite_to_squad, leave_squad, mine, rush, upgrade_device

router = Router(name="coins")


@router.message(Command("job", "task"))
@router.message(F.text.lower().in_({"добыть", "работать"}))
async def job_cmd(message: Message) -> None:
    u = message.from_user
    async with session_scope() as session:
        amount, balance, level = await mine(session, u.id, u.username, u.full_name)
    if amount <= 0:
        await message.answer(f"⛏ Добыча не удалась. Уровень прибора: {level}. Баланс: {balance}.")
    else:
        await message.answer(f"⛏ Добыто монет: <b>{amount}</b>\nБаланс: <b>{balance}</b>\nПрибор: <b>{level}/15</b>")


@router.message(Command("upgrade"))
async def upgrade_cmd(message: Message) -> None:
    u = message.from_user
    async with session_scope() as session:
        ok, text = await upgrade_device(session, u.id, u.username, u.full_name)
    await message.answer(("✅ " if ok else "❌ ") + text)


@router.message(Command("rush"))
async def rush_cmd(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2 or not parts[1].isdigit():
        await message.answer("Используй: /rush 100")
        return
    amount = int(parts[1])
    u = message.from_user
    async with session_scope() as session:
        ok, text = await rush(session, u.id, amount, u.username, u.full_name)
    await message.answer(("✅ " if ok else "❌ ") + text)


@router.message(Command("sqcreate"))
async def sqcreate_cmd(message: Message) -> None:
    parts = (message.text or "").split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("Используй: /sqcreate Название")
        return
    async with session_scope() as session:
        ok, text = await create_squad(session, message.from_user.id, parts[1])
    await message.answer(("✅ " if ok else "❌ ") + text)


@router.message(Command("inv"))
async def inv_cmd(message: Message) -> None:
    if not message.reply_to_message or not message.reply_to_message.from_user:
        await message.answer("Ответь на сообщение пользователя командой /inv.")
        return
    async with session_scope() as session:
        ok, text = await invite_to_squad(session, message.from_user.id, message.reply_to_message.from_user.id)
    await message.answer(("✅ " if ok else "❌ ") + text)


@router.message(Command("sqleave"))
async def sqleave_cmd(message: Message) -> None:
    async with session_scope() as session:
        ok, text = await leave_squad(session, message.from_user.id)
    await message.answer(("✅ " if ok else "❌ ") + text)
