from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from app.config import settings

router = Router(name="applications")


@router.message(Command("apply"))
async def apply_cmd(message: Message) -> None:
    text = (message.text or "").split(maxsplit=1)
    if len(text) < 2:
        await message.answer("Отправь заявку так: /apply текст заявки")
        return
    body = text[1]
    await message.answer("✅ Заявка принята и отправлена персоналу." if settings.staff_group_id else "✅ Заявка принята. STAFF_GROUP_ID не указан, пересылка выключена.")
    if settings.staff_group_id:
        await message.bot.send_message(
            settings.staff_group_id,
            "📥 <b>Новая экспресс-заявка</b>\n"
            f"От: <a href='tg://user?id={message.from_user.id}'>{message.from_user.full_name}</a>\n\n"
            f"{body}\n\n"
            "Кнопка проверки ровности: TODO подключить к внешней базе/скорингу.",
        )
