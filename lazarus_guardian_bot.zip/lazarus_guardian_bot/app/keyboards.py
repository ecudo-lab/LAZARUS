from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup


def admin_panel_kb() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text="🛡 Guardian", callback_data="panel:guardian")],
        [InlineKeyboardButton(text="➕ Стоп-слова", callback_data="stop:add"), InlineKeyboardButton(text="➖ Стоп-слова", callback_data="stop:del")],
        [InlineKeyboardButton(text="⚠️ Тип предупреждения", callback_data="stop:type")],
        [InlineKeyboardButton(text="📝 Текст предупреждения", callback_data="stop:text")],
        [InlineKeyboardButton(text="✅ Белый список", callback_data="wl:menu"), InlineKeyboardButton(text="⛔ Чёрный список", callback_data="bl:menu")],
        [InlineKeyboardButton(text="👋 Приветствия", callback_data="welcome:menu")],
        [InlineKeyboardButton(text="🔗 Ссылки партнёра", callback_data="links:menu")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def guardian_kb(enabled: bool, name: bool, username: bool, long_words: bool) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"Guardian: {'ON' if enabled else 'OFF'}", callback_data="toggle:guardian_enabled")],
        [InlineKeyboardButton(text=f"Чекер имени: {'ON' if name else 'OFF'}", callback_data="toggle:name_checker_enabled")],
        [InlineKeyboardButton(text=f"Чекер username: {'ON' if username else 'OFF'}", callback_data="toggle:username_checker_enabled")],
        [InlineKeyboardButton(text=f"Анти-длинные слова: {'ON' if long_words else 'OFF'}", callback_data="toggle:anti_long_words_enabled")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="panel:back")],
    ])


def warning_type_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Без наказания", callback_data="stop_type:none")],
        [InlineKeyboardButton(text="Warn", callback_data="stop_type:warn"), InlineKeyboardButton(text="Mute", callback_data="stop_type:mute")],
        [InlineKeyboardButton(text="Ban", callback_data="stop_type:ban")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="panel:back")],
    ])


def list_menu_kb(prefix: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Добавить", callback_data=f"{prefix}:add")],
        [InlineKeyboardButton(text="➖ Удалить", callback_data=f"{prefix}:del")],
        [InlineKeyboardButton(text="📋 Показать список", callback_data=f"{prefix}:list")],
        [InlineKeyboardButton(text="📝 Текст предупреждения", callback_data=f"{prefix}:text")],
        [InlineKeyboardButton(text="⬅️ Назад", callback_data="panel:back")],
    ])


def games_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎲 Кости", callback_data="game:new:dice"), InlineKeyboardButton(text="🎯 Дартс", callback_data="game:new:darts")],
        [InlineKeyboardButton(text="🏀 Баскетбол", callback_data="game:new:basketball"), InlineKeyboardButton(text="🎳 Боулинг", callback_data="game:new:bowling")],
        [InlineKeyboardButton(text="🎰 Рулетка список", callback_data="game:new:roulette_list")],
        [InlineKeyboardButton(text="🎰 Рулетка хэштег", callback_data="game:new:roulette_hashtag")],
        [InlineKeyboardButton(text="🎰 Бинго", callback_data="game:new:bingo")],
    ])


def start_game_kb(session_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="▶️ Начать игру", callback_data=f"game:start:{session_id}")],
    ])


def roll_kb(session_id: int, action: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=action, callback_data=f"game:roll:{session_id}")],
    ])
