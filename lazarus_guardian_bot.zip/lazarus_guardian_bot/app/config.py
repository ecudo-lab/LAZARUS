from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    bot_token: str
    owner_ids: str = ""
    database_url: str = "sqlite+aiosqlite:///./lazarus.db"
    redis_url: str = ""
    staff_group_id: int = 0
    default_warning_text: str = "⚠️ Нарушение правил группы."
    default_blacklist_text: str = "⛔ Пользователь находится в чёрном списке."
    default_forward_warning: str = "⚠️ Пересылка сообщений ограничена."
    auto_link_ttl_hours: int = 24

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def owners(self) -> set[int]:
        result: set[int] = set()
        for part in self.owner_ids.replace(";", ",").split(","):
            part = part.strip()
            if part.lstrip("-").isdigit():
                result.add(int(part))
        return result


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
