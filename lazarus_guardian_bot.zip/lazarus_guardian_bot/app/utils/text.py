from __future__ import annotations

import re
from html import escape

USERNAME_RE = re.compile(r"@?[A-Za-z0-9_]{3,32}")
SIGNUP_RE = re.compile(r"^([#@][^\s]+)(?:\s+(\d+))?(?:\s+((?:\d+\s*){5,}))?$", re.IGNORECASE)
LONG_WORD_RE = re.compile(r"\S{100,}")


def h(value: object) -> str:
    return escape(str(value), quote=False)


def user_key(user_id: int | None = None, username: str | None = None) -> str:
    if username:
        username = username.strip().lower().lstrip("@")
        if username:
            return f"@{username}"
    if user_id is not None:
        return str(user_id)
    return ""


def normalize_words(text: str) -> list[str]:
    result: list[str] = []
    for line in text.replace(",", "\n").splitlines():
        word = line.strip().lower()
        if word:
            result.append(word)
    return sorted(set(result))


def parse_user_arg(text: str | None) -> str | None:
    if not text:
        return None
    parts = text.strip().split(maxsplit=1)
    if len(parts) < 2:
        return None
    return parts[1].strip()


def parse_signup(text: str) -> tuple[str, int | None, list[int] | None] | None:
    match = SIGNUP_RE.match(text.strip())
    if not match:
        return None
    tag, slot_raw, nums_raw = match.groups()
    slot = int(slot_raw) if slot_raw else None
    numbers: list[int] | None = None
    if nums_raw:
        parsed = [int(x) for x in re.findall(r"\d+", nums_raw)]
        if len(parsed) >= 5:
            numbers = parsed[:5]
    return tag, slot, numbers


def valid_bingo_numbers(numbers: list[int] | None) -> bool:
    return bool(numbers and len(numbers) == 5 and len(set(numbers)) == 5 and all(1 <= n <= 100 for n in numbers))
