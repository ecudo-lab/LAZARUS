from __future__ import annotations

from datetime import datetime, timezone
from enum import StrEnum

from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class WarningType(StrEnum):
    none = "none"
    warn = "warn"
    mute = "mute"
    ban = "ban"


class ChatSettings(Base):
    __tablename__ = "chat_settings"

    chat_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    title: Mapped[str | None] = mapped_column(String(255), nullable=True)
    guardian_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    name_checker_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    username_checker_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    anti_long_words_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    stop_warning_type: Mapped[str] = mapped_column(String(20), default=WarningType.none.value)
    stop_warning_text: Mapped[str] = mapped_column(Text, default="⚠️ Стоп-слово запрещено.")
    blacklist_text: Mapped[str] = mapped_column(Text, default="⛔ Пользователь находится в чёрном списке.")
    forward_warning_text: Mapped[str] = mapped_column(Text, default="⚠️ Пересылка сообщений ограничена.")
    advert_interval_minutes: Mapped[int] = mapped_column(Integer, default=60)
    custom_partner_link: Mapped[str | None] = mapped_column(String(512), nullable=True)
    auto_partner_link: Mapped[str | None] = mapped_column(String(512), nullable=True)
    auto_partner_link_updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc, onupdate=now_utc)


class UserProfile(Base):
    __tablename__ = "user_profiles"

    user_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    full_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    last_full_name: Mapped[str | None] = mapped_column(String(255), nullable=True)
    coins: Mapped[int] = mapped_column(Integer, default=0)
    device_level: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc, onupdate=now_utc)


class StopWord(Base):
    __tablename__ = "stop_words"
    __table_args__ = (UniqueConstraint("chat_id", "word", name="uq_stop_words_chat_word"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    word: Mapped[str] = mapped_column(String(255), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class WhiteListUser(Base):
    __tablename__ = "whitelist_users"
    __table_args__ = (UniqueConstraint("chat_id", "user_key", name="uq_whitelist_chat_user_key"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_key: Mapped[str] = mapped_column(String(255), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class BlackListUser(Base):
    __tablename__ = "blacklist_users"
    __table_args__ = (UniqueConstraint("chat_id", "user_key", name="uq_blacklist_chat_user_key"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_key: Mapped[str] = mapped_column(String(255), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class WarningRecord(Base):
    __tablename__ = "warnings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class ForwardLog(Base):
    __tablename__ = "forward_logs"
    __table_args__ = (UniqueConstraint("chat_id", "user_id", name="uq_forward_logs_chat_user"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    last_forward_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class Trigger(Base):
    __tablename__ = "triggers"
    __table_args__ = (UniqueConstraint("chat_id", "name", name="uq_triggers_chat_name"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    name: Mapped[str] = mapped_column(String(128), index=True)
    text: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class MessageStat(Base):
    __tablename__ = "message_stats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc, index=True)


class PartnerTransition(Base):
    __tablename__ = "partner_transitions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc, index=True)


class WelcomeMessage(Base):
    __tablename__ = "welcome_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    text: Mapped[str] = mapped_column(Text)
    media_file_id: Mapped[str | None] = mapped_column(String(512), nullable=True)
    media_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    button_text: Mapped[str | None] = mapped_column(String(128), nullable=True)
    button_url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class GameSession(Base):
    __tablename__ = "game_sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    game_type: Mapped[str] = mapped_column(String(50), index=True)
    status: Mapped[str] = mapped_column(String(20), default="registration")
    hashtag: Mapped[str | None] = mapped_column(String(128), nullable=True)
    pinned_message_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    stopped_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    participants: Mapped[list["GameParticipant"]] = relationship(back_populates="session", cascade="all, delete-orphan")


class GameParticipant(Base):
    __tablename__ = "game_participants"
    __table_args__ = (UniqueConstraint("session_id", "user_id", "slot", name="uq_game_participant_session_user_slot"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[int] = mapped_column(ForeignKey("game_sessions.id", ondelete="CASCADE"), index=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    display_name: Mapped[str] = mapped_column(String(255))
    slot: Mapped[int | None] = mapped_column(Integer, nullable=True)
    numbers: Mapped[str | None] = mapped_column(String(255), nullable=True)
    score: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
    session: Mapped[GameSession] = relationship(back_populates="participants")


class BingoLine(Base):
    __tablename__ = "bingo_lines"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[int] = mapped_column(ForeignKey("game_sessions.id", ondelete="CASCADE"), index=True)
    number: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class Squad(Base):
    __tablename__ = "squads"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(128), unique=True)
    owner_id: Mapped[int] = mapped_column(BigInteger, index=True)
    storage_coins: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class SquadMember(Base):
    __tablename__ = "squad_members"
    __table_args__ = (UniqueConstraint("user_id", name="uq_squad_members_user"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    squad_id: Mapped[int] = mapped_column(ForeignKey("squads.id", ondelete="CASCADE"), index=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)


class Debtor(Base):
    __tablename__ = "debtors"
    __table_args__ = (UniqueConstraint("chat_id", "user_id", name="uq_debtors_chat_user"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    chat_id: Mapped[int] = mapped_column(BigInteger, index=True)
    user_id: Mapped[int] = mapped_column(BigInteger, index=True)
    username: Mapped[str | None] = mapped_column(String(255), nullable=True)
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now_utc)
